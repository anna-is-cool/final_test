package first;

import first.Elevator;

public class OddElevator extends Elevator {
}
