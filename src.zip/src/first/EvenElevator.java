package first;

import first.Elevator;

public class EvenElevator extends Elevator {
}
