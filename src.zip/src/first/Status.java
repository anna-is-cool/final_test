package first;

public enum Status {
    FREE, TAKEN
}
