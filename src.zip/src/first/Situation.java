package first;

public enum Situation {
    EVEN, ODD, WORKER
}
