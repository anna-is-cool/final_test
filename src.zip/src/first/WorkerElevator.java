package first;

import first.Elevator;

public class WorkerElevator extends Elevator {
}
