package first;

import first.Elevator;

public interface FindFree {
    Elevator free();
}
