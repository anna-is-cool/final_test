package first;

public interface Callable {
    Elevator call(Situation situation);
}
