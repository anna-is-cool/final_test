package first;

public class AllOccupiedException extends Exception{
    public AllOccupiedException(String message){super(message);}
}
